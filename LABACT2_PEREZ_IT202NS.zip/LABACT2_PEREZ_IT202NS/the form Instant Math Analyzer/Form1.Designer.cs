﻿namespace the_form_Instant_Math_Analyzer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.num1 = new System.Windows.Forms.Label();
            this.num2 = new System.Windows.Forms.Label();
            this.num3 = new System.Windows.Forms.Label();
            this.num4 = new System.Windows.Forms.Label();
            this.num5 = new System.Windows.Forms.Label();
            this.labelResult = new System.Windows.Forms.Label();
            this.Result = new System.Windows.Forms.Label();
            this.EnterNumber = new System.Windows.Forms.GroupBox();
            this.ResultBox = new System.Windows.Forms.GroupBox();
            this.EnterNumber.SuspendLayout();
            this.ResultBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(199, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(150, 20);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(199, 133);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(150, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(199, 246);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(150, 20);
            this.textBox3.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(199, 190);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(150, 20);
            this.textBox4.TabIndex = 3;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(199, 304);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(150, 20);
            this.textBox6.TabIndex = 5;
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCalculate.Location = new System.Drawing.Point(524, 470);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(145, 49);
            this.buttonCalculate.TabIndex = 6;
            this.buttonCalculate.Text = "Calculate";
            this.buttonCalculate.UseVisualStyleBackColor = false;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.SkyBlue;
            this.buttonClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClear.Location = new System.Drawing.Point(737, 470);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(145, 49);
            this.buttonClear.TabIndex = 7;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Brown;
            this.buttonExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(972, 470);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(145, 49);
            this.buttonExit.TabIndex = 8;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // num1
            // 
            this.num1.AutoSize = true;
            this.num1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num1.Location = new System.Drawing.Point(56, 74);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(132, 25);
            this.num1.TabIndex = 9;
            this.num1.Text = "1st Number";
            // 
            // num2
            // 
            this.num2.AutoSize = true;
            this.num2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num2.Location = new System.Drawing.Point(56, 133);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(139, 25);
            this.num2.TabIndex = 10;
            this.num2.Text = "2nd Number";
            this.num2.Click += new System.EventHandler(this.label2_Click);
            // 
            // num3
            // 
            this.num3.AutoSize = true;
            this.num3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num3.Location = new System.Drawing.Point(61, 190);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(134, 25);
            this.num3.TabIndex = 11;
            this.num3.Text = "3rd Number";
            // 
            // num4
            // 
            this.num4.AutoSize = true;
            this.num4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num4.Location = new System.Drawing.Point(61, 246);
            this.num4.Name = "num4";
            this.num4.Size = new System.Drawing.Size(133, 25);
            this.num4.TabIndex = 12;
            this.num4.Text = "4th Number";
            this.num4.Click += new System.EventHandler(this.label4_Click);
            // 
            // num5
            // 
            this.num5.AutoSize = true;
            this.num5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num5.Location = new System.Drawing.Point(61, 299);
            this.num5.Name = "num5";
            this.num5.Size = new System.Drawing.Size(133, 25);
            this.num5.TabIndex = 13;
            this.num5.Text = "5th Number";
            // 
            // labelResult
            // 
            this.labelResult.AutoSize = true;
            this.labelResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelResult.Location = new System.Drawing.Point(23, 83);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(79, 25);
            this.labelResult.TabIndex = 14;
            this.labelResult.Text = "Result";
            this.labelResult.Click += new System.EventHandler(this.labelResult_Click);
            // 
            // Result
            // 
            this.Result.AutoSize = true;
            this.Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result.Location = new System.Drawing.Point(126, 43);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(79, 25);
            this.Result.TabIndex = 15;
            this.Result.Text = "Result";
            // 
            // EnterNumber
            // 
            this.EnterNumber.Controls.Add(this.num5);
            this.EnterNumber.Controls.Add(this.num4);
            this.EnterNumber.Controls.Add(this.num3);
            this.EnterNumber.Controls.Add(this.num2);
            this.EnterNumber.Controls.Add(this.num1);
            this.EnterNumber.Controls.Add(this.textBox6);
            this.EnterNumber.Controls.Add(this.textBox4);
            this.EnterNumber.Controls.Add(this.textBox3);
            this.EnterNumber.Controls.Add(this.textBox2);
            this.EnterNumber.Controls.Add(this.textBox1);
            this.EnterNumber.Location = new System.Drawing.Point(53, 90);
            this.EnterNumber.Name = "EnterNumber";
            this.EnterNumber.Size = new System.Drawing.Size(433, 358);
            this.EnterNumber.TabIndex = 16;
            this.EnterNumber.TabStop = false;
            this.EnterNumber.Text = "groupBox1";
            this.EnterNumber.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // ResultBox
            // 
            this.ResultBox.Controls.Add(this.Result);
            this.ResultBox.Controls.Add(this.labelResult);
            this.ResultBox.Location = new System.Drawing.Point(524, 90);
            this.ResultBox.Name = "ResultBox";
            this.ResultBox.Size = new System.Drawing.Size(593, 357);
            this.ResultBox.TabIndex = 17;
            this.ResultBox.TabStop = false;
            this.ResultBox.Text = "groupBox2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1177, 683);
            this.Controls.Add(this.ResultBox);
            this.Controls.Add(this.EnterNumber);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonCalculate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.EnterNumber.ResumeLayout(false);
            this.EnterNumber.PerformLayout();
            this.ResultBox.ResumeLayout(false);
            this.ResultBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label num1;
        private System.Windows.Forms.Label num2;
        private System.Windows.Forms.Label num3;
        private System.Windows.Forms.Label num4;
        private System.Windows.Forms.Label num5;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.Label Result;
        private System.Windows.Forms.GroupBox EnterNumber;
        private System.Windows.Forms.GroupBox ResultBox;
    }
}

